/*
Dec. 03. 2006, by Haru Ji
To the Fractal
Complex Arithmetic -> (a + bi) * (c + di) = (ac - bd) + (ad + bc)i. 
Golden rule for C++ -> never multiply between imaginery numbers and real numbers
Do build solution each new line
Do start debugging
Do Math using Exel or calculation
*/

#include "MyApplication.h"
#include <math.h>

#define texturesize 512

void MyApplication::HaruMain ()
{
	// Haru's code, Iteration, For Fractal          
	float nr, ni, cr = 0, ci = 0, or, oi; 
	int MaxIteration = 40;
	float ColorValue;

	float addX, addY, x = 0, y = 0;

	//Zoom In & Out with two points
	float x1 = 0, y1 = 0, x2 = 512, y2 = 512;
	
	//Zoom In & Out with one point
	float x0, y0, sc = 256;
	
	x0 = (mousex * (abs(x2 - x1))/texturesize) + x1;
	y0 = (mousey * (abs(y2 - y1))/texturesize) + y1;
	
	x1 = x0 - sc/zoomLevel ; x2 = x0 + sc/zoomLevel; 
	y1 = y0 - sc/zoomLevel ; y2 = y0 + sc/zoomLevel;

	Fill ( 0, 0, 0);

		addX = (abs(x2 - x1))/texturesize;
		addY = (abs(y2 - y1))/texturesize;

			for (float i = x1; i < x2; i+= addX)
			{
				x = x + 1; 
				y = 0;

				for (float j = y1; j < y2; j+= addY)
				{	

					cr = (i / (128.0f)) - 2.f; // scaling
					ci = (j / (128.0f)) - 2.f; // scaling

					or = 0, oi = 0;

					y = y + 1;

					for (int k=0; k<MaxIteration ; k++)
					{
						nr = (or * or) - (oi * oi) + cr;
						ni = (2 * or * oi) + ci;
						or = nr;
						oi = ni;

						if ( sqrt((nr * nr) + (ni * ni)) >= 2 ) // Coloring: Red gradation + no level
						{
							ColorValue = sqrt((nr * nr) + (ni * ni));
							SetPixel (x, y, ColorValue/5.1 + (zoomLevel * .01f), ColorValue/9.2 + (zoomLevel * .02f), ColorValue/8.9); //x, y(imaginery), r, g, b
							break;
						}
					}
				}
			}

	UpdateTexture ();
}


void MyApplication::SetPixel(int x, int y, float r, float g, float b)
{
	// (coded with help from Rama - see HaruMain) _01
	int offset;
	if ( x < 0 || x >= texturesize || y < 0 || y >= texturesize) return; 
	offset = y*tpitch + (x<<2);
	texturedata[offset + 0] = r;
	texturedata[offset + 1] = g;
	texturedata[offset + 2] = b;
	texturedata[offset + 3] = 0.0f;
	
}

void MyApplication::Fill ( float r, float g, float b )
{
	// (coded with help from Rama - see HaruMain) _02
	int i, j;
	int offset;

	for (i=0; i < texturesize; i++) {
		for (j=0; j < texturesize; j++) {
			offset = i*tpitch + (j<<2);
			texturedata[offset + 0] = r;
			texturedata[offset + 1] = g;
			texturedata[offset + 2] = b;
			texturedata[offset + 3] = 0.0f;
		}
	}
	UpdateTexture ();
}

void MyApplication::UpdateTexture ()
{
	// (coded with help from Rama - see HaruMain) _03
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexImage2D( GL_TEXTURE_2D, 0, 4, texturesize, texturesize, 0, GL_RGBA, GL_FLOAT, texturedata);
}

void MyApplication::onMouseLButtonDown(int X, int Y)
{
	mousex = X;
	mousey = Y;

	zoomLevel++;

	HaruMain();
}

void MyApplication::onMouseRButtonDown(int X, int Y)
{
	mousex = X;
	mousey = Y;

	if (zoomLevel > 1)
		zoomLevel--;

	HaruMain();
}

MyApplication::MyApplication (char *title, char *arg, int l, int t, int w, int h, bool fullscreen) : Application(title, fullscreen, l, t, w, h)
{
	// (coded with help from Rama - see HaruMain)
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glEnable(GL_DEPTH_TEST);

	// Create a texture to store an image
	texturedata = new float [texturesize * texturesize * 4];
	tpitch = texturesize*4;
    memset(texturedata, 0, sizeof(float) * 4 * texturesize * texturesize);
	
	// Create new OpenGL texture
	glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	glEnable(GL_TEXTURE_2D);

	// Update it the first time
	Fill ( 0, 0, 0);
	UpdateTexture();

	mousex = 256;
	mousey = 256;
	zoomLevel = 1;

	// Do haru's stuff
	HaruMain ();
}

MyApplication::~MyApplication()
{
}

void MyApplication::onDraw()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);

	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrtho(0, width, height, 0, 0, 1);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glColor3f(1.0f, 1.0f, 1.0f);

	glBindTexture(GL_TEXTURE_2D, texture);
	glBegin(GL_QUADS);
	glTexCoord2f(0.f, 0.f); glVertex3f(0.f, 0.f, 0.f);
	glTexCoord2f(0.f, 1.f); glVertex3f(0.f, height, 0.f);
	glTexCoord2f(1.f, 1.f); glVertex3f(width, height, 0.f);
	glTexCoord2f(1.f, 0.f); glVertex3f(width, 0.f, 0.f);
	glEnd();

	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);

	glDisable(GL_COLOR_MATERIAL);
	glDisable(GL_LIGHTING);
	glDisable(GL_LIGHT0);
}